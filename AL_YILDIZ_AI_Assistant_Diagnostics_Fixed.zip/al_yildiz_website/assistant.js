(() => {
  if (window.__ALYILDIZ_AI_LOADED__) return;
  window.__ALYILDIZ_AI_LOADED__ = true;
  const script = document.currentScript;
  const base = new URL(".", script.src);
  const style = document.createElement("link");
  style.rel = "stylesheet"; style.href = new URL("assistant.css", base).href;
  document.head.appendChild(style);

  const labels = {
    en: {title:"AL-YILDIZ AI Assistant", hello:"Hello! I can help candidates and Gulf companies with job and service enquiries.", placeholder:"Type your question...", send:"Send", candidate:"Job candidate", company:"Company / client", wa:"Contact our office on WhatsApp", lang:"Language", err:"I couldn't reach the AI service just now. Please contact our office on WhatsApp."},
    hi: {title:"AL-YILDIZ AI सहायक", hello:"नमस्ते! मैं नौकरी के उम्मीदवारों और Gulf कंपनियों की जानकारी में मदद कर सकता हूँ।", placeholder:"अपना सवाल लिखें...", send:"भेजें", candidate:"नौकरी उम्मीदवार", company:"कंपनी / क्लाइंट", wa:"WhatsApp पर ऑफिस से संपर्क करें", lang:"भाषा", err:"अभी AI सेवा से संपर्क नहीं हो पाया। कृपया WhatsApp पर ऑफिस से संपर्क करें।"},
    ar: {title:"مساعد AL-YILDIZ الذكي", hello:"مرحباً! يمكنني مساعدة المرشحين والشركات في استفسارات الوظائف والخدمات.", placeholder:"اكتب سؤالك هنا...", send:"إرسال", candidate:"باحث عن عمل", company:"شركة / عميل", wa:"تواصل مع المكتب عبر واتساب", lang:"اللغة", err:"تعذر الاتصال بخدمة الذكاء الاصطناعي الآن. يرجى التواصل مع المكتب عبر واتساب."}
  };
  const wa = "https://wa.me/917209556227";
  const root = document.createElement("div"); root.id = "alyildiz-ai-root";
  root.innerHTML = `
    <button class="ay-fab" aria-label="Open AL-YILDIZ AI Assistant"><span>✦</span><b>AI ASSISTANT</b></button>
    <section class="ay-panel" aria-label="AL-YILDIZ AI Assistant" hidden>
      <header class="ay-head"><div><strong class="ay-title">AL-YILDIZ AI Assistant</strong><small>Job & company enquiry support</small></div><button class="ay-close" aria-label="Close">×</button></header>
      <div class="ay-tools">
        <label><span class="ay-lang-label">Language</span>
          <select class="ay-lang" aria-label="Language"><option value="en">English</option><option value="hi">हिन्दी</option><option value="ar">العربية</option></select>
        </label>
        <select class="ay-role" aria-label="Enquiry type"><option value="candidate">Job candidate</option><option value="company">Company / client</option></select>
      </div>
      <div class="ay-quick" aria-label="Popular questions">
        <button type="button" data-prompt="I want to enquire about a Gulf job.">Gulf Jobs</button>
        <button type="button" data-prompt="I need information about a visa.">Visa Help</button>
        <button type="button" data-prompt="How can I check my application file status?">File Status</button>
        <button type="button" data-prompt="I want to speak to your office.">Talk to Office</button>
      </div>
      <div class="ay-messages" aria-live="polite"></div>
      <form class="ay-form"><input class="ay-input" maxlength="1200" required autocomplete="off"><button class="ay-send" type="submit">Send</button></form>
      <a class="ay-wa" target="_blank" rel="noopener" href="${wa}">Contact our office on WhatsApp</a>
      <div class="ay-foot">Please verify job and payment details directly with the office.</div>
    </section>`;
  document.body.appendChild(root);
  const $ = s => root.querySelector(s);
  let history = [];
  let lang = "en";
  const panel = $(".ay-panel"), messages = $(".ay-messages");
  function add(text, who) { const el = document.createElement("div"); el.className = "ay-msg " + who; el.textContent = text; messages.appendChild(el); messages.scrollTop = messages.scrollHeight; }
  function applyLang() {
    const t = labels[lang]; $(".ay-title").textContent=t.title; $(".ay-lang-label").textContent=t.lang;
    $(".ay-input").placeholder=t.placeholder; $(".ay-send").textContent=t.send;
    $(".ay-role").options[0].textContent=t.candidate; $(".ay-role").options[1].textContent=t.company;
    $(".ay-wa").textContent=t.wa; $(".ay-panel").dir = lang === "ar" ? "rtl" : "ltr";
    if (!messages.dataset.greeted) { add(t.hello, "bot"); messages.dataset.greeted="1"; }
  }
  function setOpen(open) { panel.hidden = !open; root.classList.toggle("ay-open", open); if (open) $(".ay-input").focus(); }
  $(".ay-fab").addEventListener("click", () => setOpen(panel.hidden));
  $(".ay-close").addEventListener("click", () => setOpen(false));
  root.querySelectorAll("[data-prompt]").forEach(button => button.addEventListener("click", () => {
    $(".ay-input").value = button.dataset.prompt;
    $(".ay-form").requestSubmit();
  }));
  $(".ay-lang").addEventListener("change", e => { lang=e.target.value; history=[]; messages.innerHTML=""; delete messages.dataset.greeted; applyLang(); });
  applyLang();
  $(".ay-form").addEventListener("submit", async e => {
    e.preventDefault();
    const input=$(".ay-input"), question=input.value.trim(); if (!question) return;
    add(question, "user"); input.value=""; $(".ay-send").disabled=true;
    const pending=document.createElement("div"); pending.className="ay-msg bot"; pending.textContent="…"; messages.appendChild(pending);
    try {
      const res=await fetch("/.netlify/functions/alyildiz-chat", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body:JSON.stringify({message:question, language:lang, role:$(".ay-role").value, history})
      });
      let data = {};
      try { data = await res.json(); } catch (_) {}
      if (!res.ok) {
        const detail = data.error || data.detail || `Server returned HTTP ${res.status}`;
        throw new Error(detail);
      }
      pending.textContent=data.reply || labels[lang].err;
      history.push({role:"user",content:question},{role:"assistant",content:pending.textContent});
      history=history.slice(-12);
    } catch (error) {
      const detail = error && error.message ? error.message : "Unknown connection error";
      pending.textContent = `${labels[lang].err}\n\nTechnical detail: ${detail}`;
    }
    finally { $(".ay-send").disabled=false; messages.scrollTop=messages.scrollHeight; }
  });
})();