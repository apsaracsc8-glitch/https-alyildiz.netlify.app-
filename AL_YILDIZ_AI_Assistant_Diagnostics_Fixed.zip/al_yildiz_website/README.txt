AL-YILDIZ Gulf Job Consultancy website
======================================

Included:
- index.html — website content
- style.css — responsive styling
- script.js — mobile menu and current year
- assets/al-yildiz-logo.png — cropped company logo from the poster you supplied
- assets/whatsapp-channel-qr.png — QR code for the official WhatsApp channel
- Expanded Gulf job categories (Electrician, AC/HVAC Technician, Plumber, Welder, Driver, Helper, Mason, Painter, Carpenter, Pipe Fitter, Technician, Cleaner, Room Attendant, Office Boy, Data Entry Operator, Accountant, Cashier, MEP & Maintenance)

WhatsApp Channel QR destination:
https://whatsapp.com/channel/0029VbDkLHGA2pL33FvQAd1z

Preview:
1. Extract the ZIP.
2. Open index.html in a browser.

Netlify:
Upload the extracted folder to the correct existing Netlify site's Deploys page.
This package is a new site bundle; it does not automatically change the live site.
Check all details and service permissions before publishing.
Visa decisions and approvals are made by the relevant authorities and are not guaranteed.
