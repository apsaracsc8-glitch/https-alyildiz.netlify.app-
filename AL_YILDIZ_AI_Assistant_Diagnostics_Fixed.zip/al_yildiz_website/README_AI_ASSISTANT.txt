AL-YILDIZ GULF JOB CONSULTANCY — WEBSITE + AI ASSISTANT
========================================================

This package includes the website, floating AI assistant and Netlify server function.

IMPORTANT: The assistant needs BOTH a deployed Netlify Function and a valid OpenAI API key. A ChatGPT subscription by itself is not an API key. Never send your API key to anyone or put it in website JavaScript.

DEPLOY CORRECTLY (REQUIRED)
1. Extract this ZIP. The Netlify site publish root must be the al_yildiz_website folder (the folder containing index.html and netlify.toml).
2. Do NOT use a static-only drag-and-drop upload if it does not deploy Netlify Functions. Connect the folder/repository to Netlify for a build deploy, or deploy using Netlify CLI.
3. In Netlify → Site configuration → Environment variables, add OPENAI_API_KEY with your own key from the OpenAI API platform. Do not use your ChatGPT password.
4. Optional: add OPENAI_MODEL = gpt-4.1-mini.
5. Trigger a fresh production deploy after adding the variable.
6. Test the endpoint: open https://YOUR-SITE/.netlify/functions/alyildiz-chat in a browser. A GET request should return “Method not allowed” (HTTP 405). A 404 means the function was not deployed. The chat itself sends POST requests.
7. Send a chat message. If configuration is still wrong, the chat now shows a technical detail such as missing API key, HTTP 404, or OpenAI API error.

NETLIFY CLI DEPLOY OPTION
- Install Node.js and Netlify CLI.
- Open a terminal in al_yildiz_website.
- Run: netlify login
- Run: netlify link (select your existing site)
- Run: netlify deploy --prod

FEATURES
- Prominent vertical AI ASSISTANT tab fixed to the right edge
- Quick buttons for Gulf Jobs, Visa Help, File Status and Talk to Office
- English, Hindi and Arabic language selection
- Candidate and Company/Client enquiry modes
- Business-specific answers based on knowledge.json
- Direct WhatsApp contact link

FILE STATUS LIMITATION
The assistant is not connected to a live CRM or application register. It must not claim to know a customer's actual file status. Staff must verify status through WhatsApp/email until a secure CRM or admin database is integrated.

UPDATING VACANCIES
Edit knowledge.json and update current_vacancies with only vacancies confirmed by your office. It is empty by default, so the assistant will not invent or claim that any vacancy is currently open. Remove/close expired vacancies.

SECURITY / ACCURACY
- Never put OPENAI_API_KEY in index.html, assistant.js, or knowledge.json.
- Never request OTPs, passwords, bank details or sensitive identity data.
- No guarantee of jobs, visa approvals, selection or processing times.
- Verify employer, written offer terms and lawful recruitment requirements before payment.

OpenAI API usage may incur separate charges.
