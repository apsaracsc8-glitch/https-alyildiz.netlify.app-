const knowledge = require("../../knowledge.json");

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors(), body: "" };
  if (event.httpMethod !== "POST") return json(405, { error: "Method not allowed" });
  if (!process.env.OPENAI_API_KEY) return json(503, { error: "Assistant is not configured yet." });
  try {
    const body = JSON.parse(event.body || "{}");
    const message = String(body.message || "").slice(0, 1200);
    const language = ["en", "hi", "ar"].includes(body.language) ? body.language : "en";
    const role = body.role === "company" ? "company/client" : "job candidate";
    if (!message.trim()) return json(400, { error: "Message required" });

    const instructions = `You are the official website assistant for ${knowledge.business_name}.
Respond in the visitor's selected language: ${language === "hi" ? "Hindi" : language === "ar" ? "Arabic" : "English"}.
Visitor type: ${role}. Help with job enquiries and company/client enquiries, plus the listed travel, visa and documentation services.
Use only the supplied business knowledge. Current vacancies are ONLY the entries in current_vacancies. If the list is empty or does not contain the requested role, clearly say you cannot confirm a current opening and direct them to WhatsApp or email.
Never invent vacancy availability, salary, employer, interview, selection, visa status or processing times. Never guarantee employment or visa approval.
Encourage verification of employer, written terms and legal recruitment requirements before any payment. Never request OTPs, passwords, bank details or sensitive identity data.
For company clients, ask concise questions about job title, number of workers, country, work location, salary, duty hours, benefits, experience, nationality preference, interview method and joining timeline; do not claim the office has accepted a mandate.
Office contacts: ${JSON.stringify(knowledge.contacts)}.
Business knowledge: ${JSON.stringify(knowledge)}.
Be polite, concise and practical.`;
    const history = Array.isArray(body.history) ? body.history.slice(-10).map(x => ({
      role: x.role === "assistant" ? "assistant" : "user",
      content: String(x.content || "").slice(0, 1500)
    })) : [];
    const apiRes = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        instructions,
        input: [...history, { role: "user", content: message }],
        max_output_tokens: 500
      })
    });
    const result = await apiRes.json();
    if (!apiRes.ok) {
      const detail = result && result.error && result.error.message ? result.error.message : `OpenAI returned HTTP ${apiRes.status}`;
      console.error("AL-YILDIZ AI provider error:", apiRes.status, detail);
      return json(502, { error: `OpenAI API error (${apiRes.status})`, detail });
    }
    const reply = (result.output || []).flatMap(x => x.content || []).filter(x => x.type === "output_text").map(x => x.text).join("\n").trim();
    return json(200, { reply: reply || "Please contact our office for assistance." });
  } catch (err) {
    return json(500, { error: "Unable to process the enquiry." });
  }
};

function cors(){ return {"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"Content-Type","Access-Control-Allow-Methods":"POST,OPTIONS"}; }
function json(statusCode, body){ return {statusCode,headers:{...cors(),"Content-Type":"application/json"},body:JSON.stringify(body)}; }